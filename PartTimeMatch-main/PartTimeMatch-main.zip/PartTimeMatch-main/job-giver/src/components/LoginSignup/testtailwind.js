import React from 'react'

const Testtailwind = () => {
  return (
    <div className='bg-gray-800 text-5xl'>
      sdfsdfsdfsdfDFsdfsdf
    </div>
  )
}

export default Testtailwind
